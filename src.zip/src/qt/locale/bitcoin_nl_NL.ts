<TS language="nl_NL" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Klik met de rechter muisknop om dit adres of label te veranderen</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Maak een nieuw adres aan</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nieuw</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopieer het geselecteerde adres naar het klembord</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>S&amp;luiten</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Verwijder het geselecteerde adres uit de lijst</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporteer de data in dit tab naar een bestand</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exporteer</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Verwijderen</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Selecteer het adres om munten naar toe te sturen.</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Selecteer het adres om munten mee te ontvangen.</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>S&amp;electeren</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Verzendadres</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Ontvangstadres</translation>
    </message>
    <message>
        <source>These are your Litecoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Dit zijn uw Litecoin adressen voor het versturen van betalingen. Controleer altijd het bedrag en het ontvangstadres voordat u munten verstuurd.</translation>
    </message>
    <message>
        <source>These are your Litecoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Dit zijn uw Litecoin adressen voor het ontvangen van betalingen. Het wordt aanbevolen om voor elke transactie een nieuw ontvangstadres te gebruiken.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Adres Kopiëren</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>ModalOverlay</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exporteer</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporteer de data in dit tab naar een bestand</translation>
    </message>
    </context>
<context>
    <name>bitcoin-core</name>
    </context>
</TS>